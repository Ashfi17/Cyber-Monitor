import React, { useEffect } from "react";

export default function Dashboard(props) {
  return (
    <div>
      <h1 style={{ textAlign: "center", padding: "100px 0" }}>404 - Not Found</h1>
    </div>
  );
}
