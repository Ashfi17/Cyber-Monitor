import axios from "axios";
import setAuthorizationToken from "./setAuthorizationToken";

// axios.defaults.headers.common = {'Authorization': `Bearer ${parsedAuthUser.access_token}`}

// const baseURL = 'http://pacbot-2030676945.us-east-2.elb.amazonaws.com/api/auth'

export const loginDetails = (values) => {
  return new Promise((resolve, reject) => {
    axios
      .post(`auth/user/login`, values)
      .then((result) => {
        if (result) {
          resolve(result);
          if (result.data.success === true) {
            localStorage.setItem(
              "currentUserLoginDetails",
              JSON.stringify(result.data)
            );
            setAuthorizationToken(result.data);
          }
        }
      })
      .catch((error) => {
        reject(error);
      });
  });
};

export const changePassword = (values) => {
  return new Promise((resolve, reject) => {
    axios
      .post(`user/changePassword`, values)
      .then((result) => {
        if (result) {
          resolve(result);
        }
      })
      .catch((error) => {
        reject(error);
      });
  });
};
